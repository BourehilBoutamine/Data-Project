import java.util.Comparator;

public class DoubleCompare implements Comparator<Double>{

	@Override
	public int compare(Double d1, Double d2)
    {         
         if (d1.compareTo(d2) ==0)
         {
             return 0;
         } 
         else 
        	 if (d1.compareTo(d2) >0) 
        	 {
        		return 1;
        	 }
        	 else  
        		 return -1;
    }

}
