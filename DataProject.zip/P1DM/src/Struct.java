import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;

import javax.swing.JTable;
import javax.swing.text.html.MinimalHTMLWriter;

public class Struct {

	private String name;
	private ArrayList<Double> values;
	
	public Struct() {
		super();
		values = new ArrayList<Double>();
		// TODO Auto-generated constructor stub
	}
	public Struct(String name, ArrayList<Double> values) {
		super();
		this.name = name;
		this.values = values;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public ArrayList<Double> getValues() {
		return values;
	}
	
	public double getValue(int i){
		return values.get(i);
	}
	
	public void setValues(int indice, Double value) {
		this.values.add(indice, value);
	}
	
	public void printValues()
	{
		for(int i=0; i<values.size(); i++)
		{
			System.out.print(values.get(i)+" ");
		}
	}
	
	public double moyenne()
	{	double moyenne =0;
		int N=0;
		for(int i=0; i<values.size(); i++)
		{
			moyenne=moyenne + values.get(i);
			N++;
		}
		return moyenne/(N);
	}

	public double mediane()
	{
		values.sort( new DoubleCompare());
		return (values.get(values.size()/2-1)+values.get(values.size()/2))/2;		
	}
	
	public ArrayList<Double> mod()
	{		
		Hashtable  vals= new Hashtable(); 		
		for(int i=0; i<values.size(); i++)
		{
			if(!vals.containsKey(values.get(i))){
				vals.put(values.get(i), 1);
			}
			else{				
				int occ=(int) vals.get(values.get(i));
				occ++;
				vals.replace(values.get(i), occ);
			}
		}
		int max= (int) vals.get(values.get(0));
		ArrayList<Double> maximums = new ArrayList<>();
		int ind=0;		
		Enumeration<Double> keys = vals.keys();
		
		if(max!=1){
			while(keys.hasMoreElements()){
				double key = keys.nextElement();
				int value =(int) (vals.get(key));
				
				if ( value >= max){
					maximums.add(ind, key);
					ind++;
				}
			}
		}
		
		return maximums;		
	}
	
	public double getMax(){
		double maximum = (double)values.get(0);
				
		for (int i = 0; i < values.size(); i++) {
			double convert=(double)values.get(i);
			if (convert > maximum) {
				maximum= convert;
			}
		}
		return maximum;
	}
	
	public double getMin(){
		double minimum = (double)values.get(0);
		
		for (int i = 0; i < values.size(); i++) {
			double convert=(double)values.get(i);
			if (convert < minimum) {
				minimum = convert;
			}
		}
		return minimum;
	}
	
	public double q1(){
		values.sort(new DoubleCompare());
		int pos=(int)values.size()*25/100;
		return values.get(pos-1);
	}
	
	public double q3(){
		values.sort(new DoubleCompare());
		int pos=(int)values.size()*75/100;
		return values.get(pos-1);
	}
	
}
