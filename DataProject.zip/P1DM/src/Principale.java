import java.awt.Frame;
import java.awt.RenderingHints;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.text.TableView.TableCell;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.FastScatterPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.category.BoxAndWhiskerRenderer;
import org.jfree.chart.renderer.category.DefaultCategoryItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset;
import org.jfree.data.xy.DefaultXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.util.Log;
import org.jfree.util.LogContext;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JSeparator;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.DefaultCellEditor;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.ListSelectionModel;
import javax.swing.JComboBox;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.JTextArea;
import javax.swing.JSlider;

public class Principale extends JFrame {
	JTable table;
	ArrayList<Struct> tab = new ArrayList<Struct>();
	DefaultTableModel jtm;
	DefaultTableModel jtm1;
	DefaultComboBoxModel jcbm;
	DefaultComboBoxModel jcbm1;
	JPanel panel_1 = new JPanel();
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	JScrollPane scrollPane_3 = new JScrollPane();
	JButton button_1 = new JButton("Calculer");
	private JTable table_1;
	public Principale() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		setTitle("Projet Data Mining");
		setSize(new Dimension(2900, 740));
		setResizable(false);
		
		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 211, 667, 444);
		panel.add(scrollPane);
		
		table = new JTable();
		table.setCellSelectionEnabled(true);
		table.setColumnSelectionAllowed(true);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
			}
		));
		
		jtm = (DefaultTableModel) table.getModel();
   		scrollPane.setViewportView(table);
		
		JButton btnQuitter = new JButton("Quitter");
		btnQuitter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		btnQuitter.setBounds(588, 677, 89, 23);
		panel.add(btnQuitter);
		
		JLabel lblListeDesAttributs = new JLabel("Liste des attributs:");
		lblListeDesAttributs.setBounds(199, 11, 126, 14);
		panel.add(lblListeDesAttributs);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {}));
		comboBox.setBounds(199, 25, 156, 20);
		jcbm=(DefaultComboBoxModel) comboBox.getModel();
		panel.add(comboBox);

		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Histogramme", "Boite \u00E0 moustaches", "Dispersion"}));
		comboBox_1.setBounds(365, 25, 156, 20);
		panel.add(comboBox_1);
		
		JButton button = new JButton("Dessiner");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dessiner(tab,comboBox.getSelectedIndex(),comboBox_1.getSelectedIndex());
			}
		});
		button.setEnabled(false);
		button.setBounds(566, 24, 111, 23);
		panel.add(button);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(72, 112, 94, 87);
		panel.add(scrollPane_1);	
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(687, 56, 649, 106);
		panel.add(scrollPane_2);
		
		JTextArea textArea = new JTextArea();
		scrollPane_2.setViewportView(textArea);
		
		JTextArea textArea_1 = new JTextArea();
		scrollPane_1.setViewportView(textArea_1);
		
		
		JButton btnNewButton = new JButton("Choisir DataSet");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser chooser = new JFileChooser();
				int returnVal = chooser.showOpenDialog(getParent());
			    if(returnVal == JFileChooser.APPROVE_OPTION) {
			    	jtm.setColumnCount(0);
			    	jtm.setRowCount(0);
			    	jcbm.removeAllElements();
			    	tab.clear();
			    	textField.setText(null);
			    	textField_1.setText(null);
			    	textField_2.setText(null);
			    	textField_3.setText(null);
			    	textField_4.setText(null);
			    	textField_5.setText(null);
			    	textArea.setText(null);
			    	button_1.setEnabled(true);
			    	textArea.setText(null);
			    	charger(chooser.getSelectedFile().getAbsolutePath());			       
			    	button.setEnabled(true);
			       }			    
			}
		});
		btnNewButton.setBounds(10, 677, 146, 23);
		panel.add(btnNewButton);		
		
		JLabel label = new JLabel("Type de graphe:");
		label.setBounds(365, 11, 118, 14);
		panel.add(label);		
		
		panel_1.setBounds(687, 211, 649, 444);
		panel.add(panel_1);
		
		JLabel label_1 = new JLabel("Moyenne:");
		label_1.setBounds(10, 59, 92, 14);
		panel.add(label_1);
		
		JLabel label_2 = new JLabel("Medianne:");
		label_2.setBounds(10, 87, 92, 14);
		panel.add(label_2);
		
		JLabel label_3 = new JLabel("Mode:");
		label_3.setBounds(10, 117, 92, 14);
		panel.add(label_3);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(72, 56, 94, 20);
		panel.add(textField);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(72, 84, 94, 20);
		panel.add(textField_1);
		
		
		scrollPane_3.setBounds(365, 56, 308, 106);
		panel.add(scrollPane_3);
		
		table_1 = new JTable();
		scrollPane_3.setViewportView(table_1);
		
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				DecimalFormat df = new DecimalFormat("0.00");
				textField.setText(df.format((tab.get(comboBox.getSelectedIndex())).moyenne()));
				textField_1.setText(df.format(tab.get(comboBox.getSelectedIndex()).mediane()));
				textField_2.setText(df.format((tab.get(comboBox.getSelectedIndex())).getMin()));
				textField_3.setText(df.format((tab.get(comboBox.getSelectedIndex())).q1()));
				textField_4.setText(df.format((tab.get(comboBox.getSelectedIndex())).q3()));
				textField_5.setText(df.format((tab.get(comboBox.getSelectedIndex())).getMax()));
				
				ArrayList<Double> maxs= (tab.get(comboBox.getSelectedIndex())).mod();
				textArea.setText(null);
				if(maxs.isEmpty()){
					textArea_1.append("il n'ya pas de mod pour cet attribut"+"\n"+"car toutes les occurances sont � 1");
				}
				else{
					for (int i = 0; i < maxs.size(); i++) {
						textArea.append(Double.toString(maxs.get(i))+"\n");
					}
				}	
			}
		});		
		button_1.setEnabled(false);
		button_1.setBounds(244, 177, 111, 23);
		panel.add(button_1);
		
		JLabel label_4 = new JLabel("Valeur minimale :");
		label_4.setBounds(176, 59, 111, 14);
		panel.add(label_4);
		
		JLabel label_5 = new JLabel("Valeur maximale :");
		label_5.setBounds(176, 142, 111, 14);
		panel.add(label_5);
		
		JLabel label_6 = new JLabel("Q1 :");
		label_6.setBounds(176, 87, 46, 14);
		panel.add(label_6);
		
		JLabel label_7 = new JLabel("Q3:");
		label_7.setBounds(176, 112, 46, 14);
		panel.add(label_7);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(267, 59, 86, 20);
		panel.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(267, 87, 86, 20);
		panel.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(267, 115, 86, 20);
		panel.add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(267, 142, 86, 20);
		panel.add(textField_5);
		
		JLabel lblAnalyses = new JLabel("Analyses :");
		lblAnalyses.setBounds(687, 28, 89, 14);
		panel.add(lblAnalyses);
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setBounds(10, 25, 156, 20);
		panel.add(comboBox_2);
		
		JLabel lblChoisirLeDataset = new JLabel("Choisir le dataset :");
		lblChoisirLeDataset.setBounds(10, 11, 146, 14);
		panel.add(lblChoisirLeDataset);
		
		JButton btnDeselectionner = new JButton("Deselectionner");
		btnDeselectionner.setBounds(538, 177, 139, 23);
		panel.add(btnDeselectionner);
		
		JButton btnToutSlectionner = new JButton("Tout S\u00E9lectionner");
		btnToutSlectionner.setBounds(365, 177, 139, 23);
		panel.add(btnToutSlectionner);
		
		JSlider slider = new JSlider();
		slider.setBounds(727, 173, 200, 26);
		panel.add(slider);
		
		JLabel lblZoom = new JLabel("Zoom:");
		lblZoom.setBounds(687, 177, 46, 14);
		panel.add(lblZoom);
		
		JButton btnEnregistrerLeGraphe = new JButton("Enregistrer le graphe");
		btnEnregistrerLeGraphe.setBounds(1164, 177, 172, 23);
		panel.add(btnEnregistrerLeGraphe);		
		
		setVisible(true);
	}
	
	
public void charger(String name){
		
		Charset charset = Charset.forName("US-ASCII");
		File file = new File(name);			
		try (BufferedReader reader = Files.newBufferedReader(file.toPath(), charset)) 
		{
			boolean bool = false;
		    String line;
		    int columns=0;
		    ArrayList<JCheckBox> checkboxes = new ArrayList<>();
		    jtm1= new DefaultTableModel();
		    jtm1.addColumn("Attributs");
		    jtm1.addColumn(new Boolean("Cocher"));
		    table_1.setModel(jtm1);
		    
			
		    while ((line = reader.readLine())!= null && !bool ) 
		    {	
		    	while(line.startsWith("@attribute")) 
		        {
		        	String[] split = line.split("\\s+");		        	
		        	Struct element = new Struct();
		        	element.setName(split[1]);
		        	tab.add(element);
		        	//checkboxes.add(new JCheckBox(split[1]));
		        	TableColumn column1 = table_1.getColumnModel().getColumn(1);
		        	JCheckBox check = new JCheckBox();
		        	check.setVisible(true);
		        	DefaultCellEditor monedit = new DefaultCellEditor(check);
					column1.setCellEditor(monedit);								
					jtm1.addRow(new Object[]{split[1],""});		        	
					jtm.addColumn(split[1]);
		        	jcbm.addElement(split[1]);
		        			        		
		        	line= reader.readLine();
		        	columns++;
		        	if (!line.startsWith("@attribute"))
		        		{
		        			bool=true;
		        		}		        	
		        }		        
		    }
		    int indice=0;		    
		    while ((line = reader.readLine()) != null) 
		    {
		    	if(!line.isEmpty())
		    	{
		    		String[] split2 = line.split(",");		    		
	    			//jtm.addRow(new Object[]{split2});
		    		jtm.insertRow(indice, split2);		    		
	    			int i=0;		    		
		    		while(i <columns && !tab.isEmpty())
		    		{
		    			tab.get(i).setValues(indice, Double.parseDouble(split2[i]));
		    			i++;
		    		}
		    		indice++;
		    	}
		    	//System.out.println(line);
		    }
			/*Iterator iter = tab.iterator();
		    while(iter.isValid())
    		{
		    	Struct a = (Struct) iter.getAttributes();
		    	System.out.println(a.getName());
    		}
		    //Iterator iter = tab.iterator();
		    
		    for(int i=0; i<columns; i++)
    		{
		    	System.out.println(tab.get(i).getName());
		    	tab.get(i).printValues();
		    	System.out.println(" ");
    		}*/	    
		    
		} catch (IOException x) {
		    System.err.format("IOException: %s%n", x);
		}		
	}

	public void dessiner(ArrayList<Struct> tab,int att,int type){
		panel_1.removeAll();
		
		
	//Disperssion
		//Tout les graphes
	if(type == 2){
		XYSeries a1 = new XYSeries(tab.get(att).getName());
		for (int i = 0; i < tab.get(att).getValues().size(); i++) {
			a1.add(i, tab.get(att).getValue(i));
		}
		XYSeries a2 = new XYSeries(tab.get(att2).getName());
		for (int i = 0; i < tab.get(att2).getValues().size(); i++) {
			a2.add(i, tab.get(att2).getValue(i));
		}
		XYSeriesCollection dataset = new XYSeriesCollection();
		dataset.addSeries(a1);
		dataset.addSeries(a2);
        
		JFreeChart jfreechart = ChartFactory.createScatterPlot(
			"scatterplot", "X", "Y", dataset,
			PlotOrientation.VERTICAL, true, true, true);
		XYPlot xyPlot = (XYPlot) jfreechart.getPlot();
		xyPlot.setDomainCrosshairVisible(true);
		xyPlot.setRangeCrosshairVisible(true);
		XYItemRenderer renderer = xyPlot.getRenderer();
		renderer.setSeriesPaint(3, Color.blue);
		
		//adjustAxis((NumberAxis) xyPlot.getDomainAxis(), true, tab.get(att2).getMin(), tab.get(att2).getMax());
		//adjustAxis((NumberAxis) xyPlot.getRangeAxis(), false, tab.get(att).getMin(), tab.get(att).getMax());
		xyPlot.setBackgroundPaint(Color.white);
		jfreechart.getRenderingHints().put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		ChartPanel panneau2= new ChartPanel(jfreechart);
		panneau2.setPreferredSize(new Dimension(649,662));
		panel_1.add(panneau2, BorderLayout.CENTER);
		panel_1.validate();

	}
	
	//Histogramme
	if(type == 0){			
		
		DefaultCategoryDataset donnees = new DefaultCategoryDataset();
		for (int i = 0; i < tab.get(att).getValues().size() ; i++) {				
			donnees.addValue(tab.get(att).getValues().get(i),String.valueOf(i+1),"");
		}
		
		JFreeChart graphe =ChartFactory.createBarChart("Histogramme de l'attribut "+ tab.get(att).getName(), "instances", "valeurs", donnees,
													   PlotOrientation.VERTICAL, false, true,true);			
		DefaultCategoryItemRenderer renderer = new DefaultCategoryItemRenderer();
		renderer.setBaseLinesVisible(true);
		ChartPanel panneau= new ChartPanel(graphe);
		panneau.setPreferredSize(new Dimension(649,662));
		panel_1.add(panneau, BorderLayout.CENTER);
		panel_1.validate();
	}

	//Boite � moustaches
	if(type==1){		
		
		DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
		List<Double> list = new ArrayList<Double>();
		
			tab.get(att).getValues().sort(new DoubleCompare());	
			for (int i = 0; i < tab.get(att).getValues().size(); i++) {
				list.add(tab.get(att).getValue(i));
			}
			dataset.add(list, " ", " ");
			
			CategoryAxis xAxis = new CategoryAxis("Attributs");
			NumberAxis yAxis = new NumberAxis("Values");
			yAxis.setRange(tab.get(att).getMin()-2, tab.get(att).getMax()+2);
			ExtendedBoxAndWhiskerRenderer renderer = new ExtendedBoxAndWhiskerRenderer();
			CategoryPlot plot = new CategoryPlot(dataset, xAxis, yAxis, renderer);
			JFreeChart chart = new JFreeChart("Box plot de l'attribut"+tab.get(att).getName(), new Font("SansSerif", Font.BOLD, 17), plot, true);
			ChartPanel chartPanel = new ChartPanel(chart);
			chartPanel.setPreferredSize(new Dimension(649,662));
			
			
			renderer.setFaroutPaint(Color.LIGHT_GRAY);
			renderer.setFillBox(false);
			renderer.setMeanVisible(false);
			renderer.setMaximumBarWidth(0.15);
			renderer.setUseOutlinePaintForWhiskers(true);
			renderer.setSeriesOutlinePaint(0, Color.BLACK);
			renderer.setSeriesOutlinePaint(1, Color.BLACK);
			
			panel_1.add(chartPanel, BorderLayout.CENTER);
			panel_1.validate();
	}
}
	
	private void adjustAxis(NumberAxis axis, boolean vertical, double min, double max) {
        axis.setRange(min, max);
        axis.setTickUnit(new NumberTickUnit((max-min)/10));
        axis.setVerticalTickLabels(vertical);
    }
}
